
<?php $__env->startSection('title', 'Data Kriteria'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
  <h2>DATA KRITERIA</h2>
<table class="table table-dark table-striped">
  <thead>
    <tr>
    <th scope="col">No</th>
      <th scope="col">Nama Kriteria</th>
      <th scope="col">Bobot</th>
      <th scope="col">Benefit</th>
    </tr>
  </thead>
</tbody>
    <?php $__currentLoopData = $datakriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <th><?php echo e($loop->iteration); ?></th>
</tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
  
</table>

          </div>
          
                    <?php $__env->stopSection(); ?>





  
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/datakriteria/halaman.blade.php ENDPATH**/ ?>