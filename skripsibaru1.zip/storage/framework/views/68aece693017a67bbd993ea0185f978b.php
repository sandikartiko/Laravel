
<?php $__env->startSection('title', ' Tambah Data Subkriteria'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white" style="width: 45rem;">
  <div class="card-header">Subkriteria Page</div>
  <div class="card-body">
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('subkriteria/' .$sub->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
       
        <label>nama</label></br>
        <input type="text" name="nama" id="nama" value="<?php echo e($sub->nama); ?>" class="form-control-sm" ></br></br>
        <div class=" form-group">
        <label>Id Kriteria</label>
        <select name="kriteria_id" id="kriteria_id" class="form-contorl">
            <option value="<?php echo e($sub->kriteria_id); ?>"><?php echo e($sub->kriteria->namakriteria); ?></option>
            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->namakriteria); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></br>
        <label>nilai</label></br>
        <input type="text" name="nilai" id="nilai" class="form-control-sm" value="<?php echo e($sub->nilai); ?>"></br></br>
      
        <input type="submit" value="Save" class="btn btn-success"></br> 
				
      
    </form>
    
  
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navsub', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/subkriteria/show.blade.php ENDPATH**/ ?>