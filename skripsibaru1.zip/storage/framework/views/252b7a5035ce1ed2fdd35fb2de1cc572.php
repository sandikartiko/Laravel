
<?php $__env->startSection('title', 'Data Kriteria'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white">
  <div class="card-header">Update Data</div>
  <div class="card-body">
      <form action="<?php echo e(url('/kriteria/' .$kriteria->id)); ?>"  method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($kriteria->id); ?>" id="id">
        <label>Nama Kriteria</label></br>
        <input type="text" name="nama" id="nama" value="<?php echo e($kriteria->nama); ?>" class="form-control"></br>
        <label>Bobot</label></br>
        <input type="text" name="bobot" id="bobot" value="<?php echo e($kriteria->bobot); ?>" class="form-control"></br>
        <label>Benefit</label></br>
        <input type="textarea" name="tipe" id="tipe" value="<?php echo e($kriteria->tipe); ?>" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
</div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('navedit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/kriteria/edit.blade.php ENDPATH**/ ?>