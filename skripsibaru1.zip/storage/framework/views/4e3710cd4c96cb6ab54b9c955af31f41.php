
<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <h2>DATA SISWA</h2>
<table class="table table-dark">
  <thead>
   sandi
  </thead>
  <tbody>
    <tr class="table-active">
      
    </tr>
    <tr>
      ...
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2" class="table-active">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
            </div>
                    <?php $__env->stopSection(); ?>





  
<?php echo $__env->make('layouts.navbarsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/siswa.blade.php ENDPATH**/ ?>