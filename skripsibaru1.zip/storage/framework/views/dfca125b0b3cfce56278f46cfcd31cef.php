
<?php $__env->startSection('title', 'Data Kriteria'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white">
  <div class="card-header">Update Data</div>
  <div class="card-body">
  <div class="card-body">
        <h5 class="card-title">Name : <?php echo e($kriteria->nama); ?></h5>
        <p class="card-text">bobot : <?php echo e($kriteria->bobot); ?></p>
        <p class="card-text">tipe : <?php echo e($kriteria->tipe); ?></p>
  </div>
   
  </div>
</div>
</div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/kriteria/show.blade.php ENDPATH**/ ?>