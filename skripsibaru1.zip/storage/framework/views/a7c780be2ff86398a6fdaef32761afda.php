
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('content'); ?>

              

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white">
  <div class="card-header">HALAMAN SISWA</div>
  <div class="card-body">
      
    <?php if(Auth::user()->role_id ==1): ?>                
    <a href="<?php echo e(url('datasiswa/create')); ?>" class="btn btn-sm btn-primary" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bxs-message-square-add bx-tada" aria-hidden="true"></i> Add New
    </a>
    <?php endif; ?>
    
    <a href="<?php echo e(url('datasiswa/exportPDF')); ?>" class="btn btn-sm btn-success" style="margin-left: 1100px; margin-top: 5;" title="">
        <i class="menu-icon tf-icons bx bxs-file-pdf bx-tada" aria-hidden="true"></i> Cetak PDF
    </a>

    <br>
    <br>
    
    <?php if(session('success')): ?>
        <div class="alert alert-primary alert-sm" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   

    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col" colspan="1">Nama Siswa</th>
                <th scope="col"colspan="1">Alamat</th>
                <th scope="col"colspan="1">Asal Sekolah </th>
                <th scope="col "colspan="1">Nomor Hp</th>
                <th scope="col ">Jenis Kelamin</th>
                <th scope="col" colspan="3">Option</th>
            </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row-> alamat); ?></td>
                <td><?php echo e($row->asal_sekolah); ?></td>
                <td><?php echo e($row->no_hp); ?></td>
                <td><?php echo e($row->jenis_kelamin); ?></td>
                
                <td> 
                    <?php if(Auth::user()->role_id !=1): ?>
                        -
                    <?php else: ?>
                   
                    <a href="<?php echo e(url('/datasiswa/'  .$row->id . '/edit')); ?>" title="Edit Siswa"><button
                            class="btn btn-primary btn-sm"><i class="bx bxs-message-alt-edit bx-burst"
                                aria-hidden="true"></i></button></a>
                                <br>
                                <br>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(url('/datasiswa' . '/' . $row->id)); ?>" accept-charset="UTF-8"
                        style="display:inline">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <?php if(Auth::user()->role_id == 1): ?>
                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Siswa"
                            onclick="return confirm('&quot;Apakah Anda Ingin Menghapus ?&quot;')"><i class="bx bx-trash bx-spin"
                                aria-hidden="true"></i></button>
                                <?php endif; ?>
                    </form>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($siswa->isEmpty()): ?>
            <tr>
                <td colspan="6">Tidak ada data siswa yang anda cari.</td>
            </tr>
        <?php endif; ?>
        <script>
    const searchInput = document.getElementById('search-input');

    searchInput.addEventListener('input', function() {
        const keyword = searchInput.value.trim();

        if (keyword.length > 0) {
            const searchForm = document.getElementById('search-form');
            searchForm.action = "<?php echo e(url('datasiswa/search')); ?>";
            searchForm.submit();
        }
    });
</script>
        </tbody>

    </table>
  
    <br>
    <ul class="pagination justify-content-center">
        <?php if($siswa->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($siswa->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>

        <?php $__currentLoopData = $siswa->getUrlRange(1, $siswa->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $siswa->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($siswa->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($siswa->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?>
    </ul>
  
   

</div>
    </div>
</div>




<?php $__env->stopSection(); ?>






  
<?php echo $__env->make('layouts.navsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/datasiswa/siswa.blade.php ENDPATH**/ ?>