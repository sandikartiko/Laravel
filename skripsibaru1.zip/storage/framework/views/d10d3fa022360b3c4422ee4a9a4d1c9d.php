
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white">
  <div class="card-header">Show Siswa</div>
  <div class="card-body">
  <div class="card-body">
        <h5 class="card-title">Nama Siswa : <?php echo e($siswa->nama); ?></h5>
        <p class="card-text">Alamat : <?php echo e($siswa->alamat); ?></p>
        <p class="card-text">Asal Sekolah : <?php echo e($siswa->asal_sekolah); ?></p>
        <p class="card-text">No Hp : <?php echo e($siswa->no_hp); ?></p>
        <p class="card-text">Jenis Kelamin : <?php echo e($siswa->jenis_kelamin); ?></p>
  </div>
   
  </div>
</div>
</div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/datasiswa/show.blade.php ENDPATH**/ ?>