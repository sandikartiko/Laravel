
<?php $__env->startSection('title', ' Tambah Data Subkriteria'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white" style="width: 45rem;">
  <div class="card-header">Subkriteria Page</div>
  <div class="card-body">
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
      <form action="<?php echo e(url('subkriteria')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>nama</label></br>
        <input type="text" name="nama" id="nama" class="form-control-sm"></br></br>
        <div class=" form-group">
        <label>Id Kriteria</label>
        <select name="kriteria_id" id="kriteria_id" class="form-contorl">
            <option value="">-pilih-</option>
            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->namakriteria); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></br>
        <label>nilai</label></br>
        <input type="text" name="nilai" id="nilai" class="form-control-sm"></br></br>
      
        <input type="submit" value="Save" class="btn btn-success"></br> 
				
      
    </form>
    
  
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navsub', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/subkriteria/create.blade.php ENDPATH**/ ?>