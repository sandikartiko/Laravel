
<?php $__env->startSection('title', 'Data Perhitungan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Menentukan Nilai S Ternormalisasi Setiap Alternatif</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Siswa</th>
                <th scope="col"> Nilai S Setiap Alternatif</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $alternatifResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatifResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($alternatifResult->alternatif_id); ?></td>
                <td><?php echo e($alternatifResult->nama_siswa); ?></td>
                <td><?php echo e($alternatifResult->nilai_s); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <br>
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">Total Nilai S Setiap Alternatif</th>
               
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($totalNilaiS); ?></td>
            </tr>
        </tbody>
       

    </table>
    <br>
    <nav>
    <ul class="pagination justify-content-center">
        <?php if($alternatifResults->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alternatifResults->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>

        <?php $__currentLoopData = $alternatifResults->getUrlRange(1, $alternatifResults->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $alternatifResults->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($alternatifResults->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alternatifResults->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?>
    </ul>
</nav>
  
   

    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/perhitungan/vektors.blade.php ENDPATH**/ ?>