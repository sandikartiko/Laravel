
<?php $__env->startSection('title', 'Data Subkriteria'); ?>
<?php $__env->startSection('content'); ?>

   

<div class="container-xxl flex-grow-1 container-p-y">

<div class="card bg-dark text-white">
<div class="card-header">Subkriteria</div>
<div class="card-body">
<?php if($message = Session::get('subkriteria_message')): ?>
				<div class="alert alert-dark">
					<strong><?php echo e($message); ?></strong>
				</div>
				<?php endif; ?>

<a href="<?php echo e(url('/subkriteria/create')); ?>" class="btn btn-sm btn-primary" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bxs-message-square-add bx-tada" aria-hidden="true"></i> Add New
    </a> 
    <br>

<table class="table table-dark table-bordered">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">nilai raport</th>
            

            <th scope="col"> Nama Kriteria</th>
            <th scope="col">Akreditasi </th>
            <th scope="col ">Option</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($loop->iteration); ?></th>
          
            <td><?php echo e($row->nama); ?></td>
            <td><?php echo e($row->kriteria->namakriteria); ?></td>
            <td><?php echo e($row->nilai); ?></td>
            <td> <a href="<?php echo e(url('/subkriteria/' . $row->id)); ?>" title="View Student"><button
                        class="btn btn-info btn-sm"><i class="bx bx-show-alt bx-fade-right bx-rotate-180"
                            aria-hidden="true"></i> Edit</button></a> ||
                <!-- <a href="<?php echo e(url('/subkriteria/'  .$row->id . '/edit')); ?>" title="Edit Student"><button
                        class="btn btn-primary btn-sm"><i class="bx bxs-message-alt-edit bx-burst"
                            aria-hidden="true"></i> Edit</button></a> -->
                <form method="POST" action="<?php echo e(url('/subkriteria' . '/' . $row->id)); ?>" accept-charset="UTF-8"
                    style="display:inline">
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                    ||
                    <button type="submit" class="btn btn-danger btn-sm" title="Delete Student"
                        onclick="return confirm('&quot;Apakah Anda Ingin Menghapus ?&quot;')"><i class="bx bx-trash bx-spin"
                            aria-hidden="true"></i> Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navsub', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/subkriteria/subkri.blade.php ENDPATH**/ ?>