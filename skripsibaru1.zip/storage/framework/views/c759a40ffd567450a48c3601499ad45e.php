
<?php $__env->startSection('title', 'Data Kriteria'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white">
  <div class="card-header">Kriteria Page</div>
  <div class="card-body">
    <!-- <button type="button" class="btn btn-sm btn-dark" href="<?php echo e(url('create')); ?>">
  <i class=' menu-icon tf-icons bx bxs-message-square-add' ></i> Add New Data
  </button> -->
  <?php if($message = Session::get('kriteria_message')): ?>
				<div class="alert alert-dark">
					<strong><?php echo e($message); ?></strong>
				</div>
				<?php endif; ?>
                
                
    <a href="<?php echo e(url('/kriteria/create')); ?>" class="btn btn-sm btn-primary" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bxs-message-square-add bx-tada" aria-hidden="true"></i> Add New
    </a> |||
    <a href="<?php echo e(url('bobot')); ?>" class="btn btn-sm btn-info" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bxs-calculator" aria-hidden="true"></i> View Bobot Nilai
    </a>

    <br>
    <br>
   

    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Kriteria</th>
                <th scope="col">Bobot</th>
                <th scope="col">Keterangan </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($row->namakriteria); ?></td>
                <td><?php echo e($row-> bobot); ?></td>
                <td><?php echo e($row->benefit); ?></td>
                
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
  
   

</div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/kepalasekolah/kriteria.blade.php ENDPATH**/ ?>