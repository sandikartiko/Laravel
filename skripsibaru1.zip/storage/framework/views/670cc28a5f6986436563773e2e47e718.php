
<?php $__env->startSection('title', 'Data Perhitungan'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Menentukan Nilai W Ternormalisasi Setiap Kriteria</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Kriteria</th>
                <th scope="col">Bobot</th>
                <th scope="col">Tipe </th>
               
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row-> bobot); ?></td>
                <td><?php echo e($row->tipe); ?></td>
                
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <br>
    <p>Total Seluruh Bobot: <?php echo e($totalBobot); ?></p>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/perhitungan/kriteria.blade.php ENDPATH**/ ?>