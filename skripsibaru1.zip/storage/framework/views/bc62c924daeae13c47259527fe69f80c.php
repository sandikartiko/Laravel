
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white">
  <div class="card-header">Update Data</div>
  <div class="card-body">
      <form action="<?php echo e(url('/datasiswa/' .$siswa->id)); ?>"  method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($siswa->id); ?>" id="id">
        <label>Nama Siswa</label></br>
        <input type="text" name="nama" id="nama" value="<?php echo e($siswa->nama); ?>" class="form-control"></br>
        <label>Alamat</label></br>
        <input type="text" name="alamat" id="alamat" value="<?php echo e($siswa->alamat); ?>" class="form-control"></br>
        <label>Asal Sekolah</label></br>
        <input type="text" name="asal_sekolah" id="asal_sekolah" value="<?php echo e($siswa->asal_sekolah); ?>" class="form-control"></br>
        <label>Nomor Hp </label></br>
        <input type="text" name="no_hp" id="no_hp" value="<?php echo e($siswa->no_hp); ?>" class="form-control"></br>
        <label>Jenis_Kelamin</label></br>
        <input type="text" name="jenis_kelamin" id="jenis_kelamin" value="<?php echo e($siswa->jenis_kelamin); ?>" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
</div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('naveditsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/datasiswa/edit.blade.php ENDPATH**/ ?>