
<?php $__env->startSection('title', 'Data alt$alt'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white">
  <div class="card-header">Update Data</div>
  <div class="card-body">
  <form action="<?php echo e(url('datanilai/'.$alt->id)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>
                <label>Id Siswa</label><br>
                <input type="text" name="id" id="id" class="form-control-sm" value="<?php echo e($alt->id); ?>"><br><br>
                <label>Nama Siswa</label><br>
                <select name="siswa_id" id="siswa_id" class="form-control-sm" required>
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $alt->siswa_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br><br>
                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label>Pilih Kriteria</label><br>
    <select name="kriteria<?php echo e($index + 1); ?>_id" id="kriteria<?php echo e($index + 1); ?>_id" class="form-control-sm" required>
        <option value="<?php echo e($item->id); ?>" <?php if($item->id == $alt->{'kriteria'.($index + 1).'_id'}): ?> selected <?php endif; ?>><?php echo e($item->nama); ?></option>
    </select><br><br>
    <label>Nilai Kriteria <?php echo e($index + 1); ?></label><br>
    <input type="text" name="nilai_kriteria<?php echo e($index + 1); ?>" id="nilai_kriteria<?php echo e($index + 1); ?>" class="form-control-sm" value="<?php echo e($alt->{'nilai_kriteria'.($index + 1)}); ?>" required><br><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="submit" value="Save" class="btn btn-success"><br> 

            </form>
   
  </div>
</div>
</div>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('naveditnilai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/datanilai/edit.blade.php ENDPATH**/ ?>