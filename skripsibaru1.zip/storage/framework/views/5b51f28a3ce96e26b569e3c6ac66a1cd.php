
<?php $__env->startSection('title', 'Data Perhitungan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">alternatif Page</div>
  <div class="card-body" >
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Siswa</th>
                <th scope="col"> Kriteria 1</th>
                <th scope="col"> Kriteria 2</th>
                <th scope="col"> Kriteria 3</th>
                <th scope="col"> Kriteria 4</th>
                <th scope="col">Nilai Kriteria 1</th>
                <th scope="col">Nilai Kriteria 2</th>
                <th scope="col">Nilai Kriteria 3</th>
                <th scope="col">Nilai Kriteria 4</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $alt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($row->id); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row->nama_kriteria1); ?></td>
                <td><?php echo e($row->nama_kriteria2); ?></td>
                <td><?php echo e($row->nama_kriteria3); ?></td>
                <td><?php echo e($row->nama_kriteria4); ?></td>
                <td><?php echo e($row->nilai_kriteria1); ?></td>
                <td><?php echo e($row->nilai_kriteria2); ?></td>
                <td><?php echo e($row->nilai_kriteria3); ?></td>
                <td><?php echo e($row->nilai_kriteria4); ?></td>
                
              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <br>
    <nav>
    <ul class="pagination justify-content-center">
        <?php if($alt->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alt->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>

        <?php $__currentLoopData = $alt->getUrlRange(1, $alt->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $alt->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($alt->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alt->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?>
    </ul>
</nav>
  </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/perhitungan/matriks.blade.php ENDPATH**/ ?>