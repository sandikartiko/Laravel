
<?php $__env->startSection('title', ': Bobot'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
<div class="card bg-dark text-white" style="width: 45rem;">
  <div class="card-header">Perhitungan Perbaikan Bobot</div>
  <div class="card-body">

  <a href="<?php echo e(url('kriteria')); ?>" class="btn btn-sm btn-danger" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bx-arrow-back bx-fade-right" aria-hidden="true"></i> Kembali
    </a>
<br>
<br>

  <table class="table table-dark table-bordered">
    <thead>
        <tr>
            <th> ID Kriteria</th>   
            <th>Nilai W</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bobotWP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krnamakriteria => $bobot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($krnamakriteria); ?></td>
            <td><?php echo e($bobot); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
</table>
<table class="table table-dark table-bordered">
    <thead>
        <tr>
            <th> ID Kriteria</th>   
            <th>nilai W ternormalisasi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bobotWP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krnamakriteria => $nilaiW): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($krnamakriteria); ?></td>
            <td><?php echo e($nilaiW); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
</table>

<table class="table table-dark table-bordered">
    <thead>
        <tr>
            <th> Alternatif</th>   
            <th>Nilai s</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vektorS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatifid_siswa => $nilaiS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($alternatifid_siswa); ?></td>
            <td><?php echo e($nilaiS); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
</table>


  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/kriteria/bobot.blade.php ENDPATH**/ ?>