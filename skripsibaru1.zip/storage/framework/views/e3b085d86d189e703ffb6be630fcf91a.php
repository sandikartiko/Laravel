
<?php $__env->startSection('title', 'Data Perhitungan'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Menentukan Nilai W Ternormalisasi Setiap Kriteria</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nama Kriteria</th>
                <th scope="col"> Bobot</th>
                <th scope="col">Nilai W Ternormalisasi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($row->id); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row->bobot); ?></td>
                <td><?php echo e($row->nilai_w); ?></td>
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      
    </table>
    <br>
    <p>Total Seluruh Bobot: <?php echo e($totalBobot); ?></p>
    </div>
    </div>
</div>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Menentukan Nilai Pangkat dengan...</div>
  <div class="card-body" >
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
            <th>Kriteria</th>
            <th>Pangkat</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($result->nama); ?></td>
            <td><?php echo e($result->nilai_pangkat); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
   
  
   

    </div>
    </div>
</div>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">alternatif Page</div>
  <div class="card-body" >
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Siswa</th>
                <th scope="col"> Kriteria 1</th>
                <th scope="col"> Kriteria 2</th>
                <th scope="col"> Kriteria 3</th>
                <th scope="col"> Kriteria 4</th>
                <th scope="col">Nilai Kriteria 1</th>
                <th scope="col">Nilai Kriteria 2</th>
                <th scope="col">Nilai Kriteria 3</th>
                <th scope="col">Nilai Kriteria 4</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $alt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($row->id); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row->nama_kriteria1); ?></td>
                <td><?php echo e($row->nama_kriteria2); ?></td>
                <td><?php echo e($row->nama_kriteria3); ?></td>
                <td><?php echo e($row->nama_kriteria4); ?></td>
                <td><?php echo e($row->nilai_kriteria1); ?></td>
                <td><?php echo e($row->nilai_kriteria2); ?></td>
                <td><?php echo e($row->nilai_kriteria3); ?></td>
                <td><?php echo e($row->nilai_kriteria4); ?></td>
                
              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <br>
    <nav>
    <ul class="pagination justify-content-center">
        <?php if($alt->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alt->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>

        <?php $__currentLoopData = $alt->getUrlRange(1, $alt->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $alt->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($alt->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alt->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?>
    </ul>
</nav>
   
  
   

    </div>
    </div>
</div>


<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Menentukan Nilai S Ternormalisasi Setiap Alternatif</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Siswa</th>
                <th scope="col"> Nilai S Setiap Alternatif</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $alternatifResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatifResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($alternatifResult->alternatif_id); ?></td>
                <td><?php echo e($alternatifResult->nama_siswa); ?></td>
                <td><?php echo e($alternatifResult->nilai_s); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <br>
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">Total Nilai S Setiap Alternatif</th>
               
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($totalNilaiS); ?></td>
            </tr>
        </tbody>
       

    </table>
    <br>
    <nav>
    <ul class="pagination justify-content-center">
        <?php if($alternatifResults->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alternatifResults->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>

        <?php $__currentLoopData = $alternatifResults->getUrlRange(1, $alternatifResults->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $alternatifResults->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($alternatifResults->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($alternatifResults->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?>
    </ul>
</nav>
  
   

    </div>
    </div>
</div>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Melakukan Perhitungan Menentukan Nilai Vektor V</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th scope="col">Nama Siswa</th>
                <th scope="col"> Nilai S / Total Nilai S</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $alternatifResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternatifResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($alternatifResult->nama_siswa); ?></td>
            <td><?php echo e($alternatifResult->nilai_s); ?> / <?php echo e($totalNilaiS); ?></td>
            
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>
</div>

<div class="container-xxl flex-grow-1 container-p-y">

    <div class="card bg-dark text-white" style="width: 100%">
  <div class="card-header">Melakukan Perhitungan Nilai Preferensi Relatif (Vektor V)</div>
  <div class="card-body" >
      
    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>
   
    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                
                <th scope="col"> Nama Siswa</th>
                <th scope="col"> Nilai V ternormalisasi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $nilaiV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($row->nama_siswa); ?></td>
                <td><?php echo e($row->nilai_v); ?></td>
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <h4 class="text-white">Jumlah Data: <?php echo e($jumlahData); ?></h4>
    <br>
    <div class="text-center">
    <a href="<?php echo e(url('perhitungan/hasil')); ?>" class="btn btn-sm btn-primary" title="Add New Kriteria">
        <i class="menu-icon tf-icons bx bxs-message-square-add bx-tada" aria-hidden="true"></i> Lihat Hasil Seleksi
    </a>
    </div>
           
    </div>
    </div>
</div>
<br>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navper', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/perhitungan/per.blade.php ENDPATH**/ ?>